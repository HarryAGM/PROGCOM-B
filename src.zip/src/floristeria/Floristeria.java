package floristeria;

public class Floristeria {

    public static void main(String[] args) {

        System.out.println(" PRUEBA DE LA SUPERCLASE 'Casa' ");
        Casa harryCasa = new Casa("Verde y Almendra. ", 6, 3, true, true);
        System.out.println(harryCasa.describir());


        System.out.println("\n PRUEBA DE LA SUBCLASE 'Flowers' ");

        Flowers miFloristeria = new Flowers("Blanco");

        System.out.println(miFloristeria.describir());

        miFloristeria.pintar("Rosa Pastel");

        System.out.println(miFloristeria.describir());
    }
}
