package floristeria;

public class Flowers extends Casa {

    private String colorFloristeria;
    private int numEsquinasConFlores;
    private String coloresFloresEsquinas;
    private int numEsquinasConMasetas;
    private String colorFrutosMasetas;
    private int numLadosConRamilletes;
    private String coloresRamilletes;
    private boolean tieneSoporteTrasero;
    private boolean tieneVentana;
    private String colorVentana;
    private boolean tienePuerta;
    private String colorPuerta;
    private boolean tieneTecho;
    private String colorTecho;

    public Flowers(String color) {
     
        super(color, 0, 0, false, false);

        this.colorFloristeria = color;

        this.tieneVentana = true;
        this.colorVentana = "azul";
        this.tienePuerta = true;
        this.colorPuerta = "azul";
        this.tieneTecho = true;
        this.colorTecho = "azul";
        this.numEsquinasConFlores = 4;
        this.coloresFloresEsquinas = "amarillas y naranjas, naranjas y moradas, moradas y rojas, rojas y amarillas";
        this.numEsquinasConMasetas = 4;
        this.colorFrutosMasetas = "todas con frutos morados";
        this.numLadosConRamilletes = 2;
        this.coloresRamilletes = "azul y rojo, naranja y morado";
        this.tieneSoporteTrasero = true;
    }

    @Override
    public String describir() {
        String descripcion = super.describir();
        descripcion += "\n\nDetalles de la Floristería:";
        descripcion += "\nColor de la floristería: " + this.colorFloristeria;
        if (tieneVentana) {
            descripcion += "\nTiene ventana de color " + this.colorVentana + ".";
        }
        if (tienePuerta) {
            descripcion += "\nTiene puerta de color " + this.colorPuerta + ".";
        }
        if (tieneTecho) {
            descripcion += "\nTiene techo de color " + this.colorTecho + ".";
        }
        descripcion += "\nTiene " + this.numEsquinasConFlores + " esquinas con flores de colores: " + this.coloresFloresEsquinas + ".";
        descripcion += "\nTiene " + this.numEsquinasConMasetas + " esquinas con macetas, " + this.colorFrutosMasetas + ".";
        descripcion += "\nTiene " + this.numLadosConRamilletes + " lados con ramilletes de colores: " + this.coloresRamilletes + ".";
        if (tieneSoporteTrasero) {
            descripcion += "\nTiene soporte trasero.";
        }
        return descripcion;
    }

    @Override
    public void pintar(String nuevoColor) {
        this.colorFloristeria = nuevoColor;

        super.pintar(nuevoColor);
        System.out.println("La floristería ha sido pintada de color " + this.colorFloristeria + " (otros elementos decorativos mantienen sus colores).");
    }
}
